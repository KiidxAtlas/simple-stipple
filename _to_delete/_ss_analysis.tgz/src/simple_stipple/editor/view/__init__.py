"""Canvas view components."""
