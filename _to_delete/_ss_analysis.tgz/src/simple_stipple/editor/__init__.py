"""Reusable interactive vector editor."""
