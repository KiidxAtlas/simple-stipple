"""Shared application dialogs."""
