"""Pattern generators package."""
