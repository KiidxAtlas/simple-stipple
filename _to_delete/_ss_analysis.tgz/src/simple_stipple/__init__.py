"""Simple Stipple package."""
