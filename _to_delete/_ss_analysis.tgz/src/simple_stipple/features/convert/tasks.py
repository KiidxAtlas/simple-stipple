"""Compatibility facade for Convert feature task forms."""

from simple_stipple.features.convert.task_forms.base import _ConversionSubTab
from simple_stipple.features.convert.task_forms.fvi import FviSubTab
from simple_stipple.features.convert.task_forms.repair import FixerSubTab
from simple_stipple.features.convert.task_forms.svg import SvgSubTab, SvgToDxfSubTab

for _task_form in (FixerSubTab, FviSubTab, SvgSubTab, SvgToDxfSubTab):
    _task_form.__module__ = __name__

__all__ = [
    "FixerSubTab",
    "FviSubTab",
    "SvgSubTab",
    "SvgToDxfSubTab",
    "_ConversionSubTab",
]
