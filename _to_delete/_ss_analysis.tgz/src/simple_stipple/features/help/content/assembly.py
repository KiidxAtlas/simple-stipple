"""Assemble manual sections and provide searchable TOC metadata."""

from __future__ import annotations

from .features import (
    _build_convert_page,
    _build_pattern_page,
    _build_pattern_types,
    _build_repo_page,
    _build_trace_page,
)
from .overview import (
    _build_bezier_pen_tool,
    _build_common_tasks,
    _build_dimension_tool,
    _build_draft_page,
    _build_files_and_recovery,
    _build_getting_started,
    _build_layers,
    _build_path_cleanup,
    _build_precision_editing,
    _build_radial_menu,
    _build_settings_updates,
    _build_text_tools,
    _toc_entry,
)
from .reference import (
    _build_canvas_commands,
    _build_production_workflows,
    _build_shortcuts,
    _build_support,
    _build_troubleshooting,
)


def build_help_html() -> str:
    """Build the complete help HTML from all sections."""
    sections = [
        _build_getting_started(),
        _build_common_tasks(),
        _build_production_workflows(),
        _build_files_and_recovery(),
        _build_precision_editing(),
        _build_draft_page(),
        _build_bezier_pen_tool(),
        _build_dimension_tool(),
        _build_radial_menu(),
        _build_path_cleanup(),
        _build_text_tools(),
        _build_layers(),
        _build_pattern_page(),
        _build_pattern_types(),
        _build_trace_page(),
        _build_convert_page(),
        _build_repo_page(),
        _build_canvas_commands(),
        _build_shortcuts(),
        _build_troubleshooting(),
        _build_settings_updates(),
        _build_support(),
    ]

    return f"""
<style>
    body {{ color: #c9d1d9; }}
    p {{ color: #c9d1d9; line-height: 1.6; }}
    li {{ color: #c9d1d9; margin-bottom: 4px; }}
    strong {{ color: #f0f6fc; }}
    em {{ color: #8b949e; }}
    a {{ color: #58a6ff; }}
    .section-heading {{
        color: #f0f6fc;
        font-size: 22px;
        font-weight: 700;
        border-bottom: 2px solid #2f81f7;
        padding-bottom: 6px;
        margin-top: 28px;
        margin-bottom: 14px;
    }}
    .subheading {{
        color: #79c0ff;
        font-size: 16px;
        font-weight: 600;
        margin-top: 20px;
        margin-bottom: 8px;
    }}
    .panel-title {{
        color: #e6edf3;
        font-size: 13px;
        font-weight: 700;
        margin-top: 14px;
        margin-bottom: 4px;
    }}
    kbd {{
        background-color: #21262d;
        border: 1px solid #30363d;
        border-radius: 4px;
        padding: 1px 6px;
        font-family: Menlo, Consolas, Courier;
        font-size: 12px;
        color: #e6edf3;
    }}
    code {{
        background-color: #161b22;
        border: 1px solid #30363d;
        border-radius: 3px;
        padding: 1px 4px;
        font-family: Menlo, Consolas, Courier;
        color: #79c0ff;
    }}
</style>

<h1 id="manual-home" style="text-align:center;color:#f0f6fc;">Simple Stipple Manual</h1>
<p style="text-align:center;color:#8b949e;">A task-first guide to drawing, patterning, image engraving, and production-ready export.</p>

<hr style="border:none;border-top:2px solid #2f81f7;margin:20px 0;">

{"".join(sections)}
"""


# ── TOC entries (section id → display label) ───────────────────────────────

TOC_ENTRIES: list[tuple[str, str]] = [
    _toc_entry("getting-started", "Start here · Getting Started"),
    _toc_entry("common-tasks", "Start here · I Want To…"),
    _toc_entry("production-workflows", "Start here · Production Workflows"),
    _toc_entry("files-recovery", "Files · Save, Import & Recover"),
    _toc_entry("precision-editing", "Edit · Select, Round & Align"),
    _toc_entry("draft-page", "Create · Draft Page"),
    _toc_entry("bezier-pen-tool", "Create · Bezier Pen"),
    _toc_entry("dimension-tool", "Create · Dimensions"),
    _toc_entry("text-tools", "Create · Text & Typography"),
    _toc_entry("pattern-page", "Create · Pattern Page"),
    _toc_entry("pattern-types", "Create · Pattern Types"),
    _toc_entry("trace-page", "Create · Trace Images"),
    _toc_entry("layers", "Organize · Layers"),
    _toc_entry("radial-menu", "Navigate · Quick Radial Menu"),
    _toc_entry("canvas-commands", "Navigate · Canvas Commands"),
    _toc_entry("keyboard-shortcuts", "Navigate · Keyboard Shortcuts"),
    _toc_entry("path-cleanup", "Edit · Path Cleanup"),
    _toc_entry("convert-page", "Files · Convert & Repair"),
    _toc_entry("repo-page", "Files · Repository Sync"),
    _toc_entry("troubleshooting", "Solve · Troubleshooting"),
    _toc_entry("settings-updates", "Configure · Settings & Updates"),
    _toc_entry("support", "Solve · Support & Diagnostics"),
]

# User vocabulary does not always match the exact control label. These aliases
# intentionally map common goals and CAD terms to the section that explains
# how to complete them.
TOC_SEARCH_TERMS: dict[str, tuple[str, ...]] = {
    "getting-started": ("begin", "first project", "new user", "overview", "workflow"),
    "common-tasks": ("how do i", "what can i do", "workflow", "quick start", "goal"),
    "production-workflows": (
        "laser",
        "production",
        "engraving workflow",
        "first export",
        "image engraving",
    ),
    "files-recovery": (
        "save",
        "open",
        "workspace",
        "autosave",
        "recover",
        "recovery",
        "import",
        "export",
        "lost work",
        "recover lost work",
        "movedist",
    ),
    "precision-editing": (
        "select",
        "round",
        "rounded corner",
        "rounded corners",
        "fillet",
        "chamfer",
        "bevel",
        "offset",
        "boolean",
        "union",
        "subtract",
        "align",
        "snap",
        "constraint",
        "construction",
    ),
    "draft-page": ("draw", "shape", "edit", "resize"),
    "bezier-pen-tool": ("curve", "handles", "pen", "smooth curve"),
    "dimension-tool": ("measure", "measurement", "length", "angle", "radius"),
    "radial-menu": ("quick menu", "tool wheel", "q menu"),
    "path-cleanup": ("smooth", "simplify", "cleanup", "repair path", "fit curve"),
    "text-tools": ("font", "lettering", "type", "text on path"),
    "layers": ("hide", "lock", "organize", "color", "group"),
    "pattern-page": (
        "engrave",
        "engraving",
        "fill",
        "generate",
        "region",
        "treatment",
        "slider",
        "decimal",
        "precision",
        "parameter value",
    ),
    "pattern-types": ("honeycomb", "voronoi", "hatch", "tile", "motif"),
    "trace-page": ("image", "photo", "bitmap", "outline", "vectorize", "threshold"),
    "convert-page": ("convert", "repair", "fix dxf", "svg", "fvi"),
    "repo-page": ("git", "pull", "push", "commit", "repository"),
    "canvas-commands": ("pan", "zoom", "select", "undo", "grid", "snap"),
    "keyboard-shortcuts": ("hotkey", "key binding", "shortcut"),
    "troubleshooting": ("problem", "error", "failed", "not working", "missing"),
    "settings-updates": (
        "settings",
        "preferences",
        "units",
        "keybindings",
        "shortcut",
        "update",
        "update app",
        "install",
        "change units",
    ),
    "support": ("settings", "preferences", "update", "logs", "help"),
}


# ── Help Dialog ───────────────────────────────────────────────────────────
