"""Application composition package."""
