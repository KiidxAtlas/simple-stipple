"""Static guards for the canonical runtime module homes."""

from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "src" / "simple_stipple"

CANONICAL_TOP_LEVEL_HOMES = {
    "app",
    "document",
    "editor",
    "engine",
    "features",
    "platform",
    "resources",
    "ui",
}
CANONICAL_EDITOR_ROOT_MODULES = {
    "__init__.py",
    "commands.py",
    "constants.py",
    "document_bridge.py",
    "hit_testing.py",
    "model.py",
    "objects.py",
    "renderer.py",
    "runtime.py",
    "service.py",
    "snap.py",
    "widget.py",
}
CANONICAL_EDITOR_SUBPACKAGES = {
    "dialogs",
    "layers",
    "operations",
    "rendering",
    "tools",
    "view",
    "widgets",
}
CANONICAL_ENGINE_SUBPACKAGES = {
    "cad",
    "editing",
    "formats",
    "geometry",
    "imaging",
    "patterns",
}


def _runtime_imports(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.add(node.module)
    return imports


def test_runtime_uses_only_canonical_top_level_homes() -> None:
    violations: list[str] = []
    for path in PACKAGE.rglob("*.py"):
        for imported in _runtime_imports(path):
            if not imported.startswith("simple_stipple."):
                continue
            home = imported.removeprefix("simple_stipple.").split(".", 1)[0]
            if home not in CANONICAL_TOP_LEVEL_HOMES:
                violations.append(f"{path.relative_to(ROOT)} imports {imported}")
    assert not violations, "\n".join(violations)


def test_runtime_tree_has_one_canonical_home_per_major_capability() -> None:
    homes = {
        path.name for path in PACKAGE.iterdir() if path.is_dir() and path.name != "__pycache__"
    }
    assert homes == CANONICAL_TOP_LEVEL_HOMES
    editor = PACKAGE / "editor"
    assert {
        path.name for path in editor.iterdir() if path.is_file()
    } == CANONICAL_EDITOR_ROOT_MODULES
    assert {
        path.name for path in editor.iterdir() if path.is_dir() and path.name != "__pycache__"
    } == CANONICAL_EDITOR_SUBPACKAGES
    assert {
        path.name
        for path in (PACKAGE / "engine").iterdir()
        if path.is_dir() and path.name != "__pycache__"
    } == CANONICAL_ENGINE_SUBPACKAGES


def test_shared_ui_and_platform_homes_have_no_root_level_facades() -> None:
    ui = PACKAGE / "ui"
    assert {path.name for path in ui.iterdir() if path.is_file()} == {"__init__.py"}
    assert {path.name for path in ui.iterdir() if path.is_dir() and path.name != "__pycache__"} == {
        "components",
        "dialogs",
        "style",
    }
    assert {path.name for path in (PACKAGE / "platform").iterdir() if path.is_file()} == {
        "__init__.py",
        "config.py",
        "error_reporting.py",
        "launcher.py",
        "settings.py",
        "storage.py",
        "updates.py",
    }
